# from flask_socketio import SocketIO
# from flask import Flask

# app=Flask(__name__)
# socketio = SocketIO(cors_allowed_origins='*')
# socketio.init_app(app)

# '''
# 此处写入监听事件
# '''

# @socketio.on('test', namespace='api')   # 监听前端发回的包头 test ,应用命名空间为 api
# def test():  # 此处可添加变量，接收从前端发回来的信息
#     print('触发test函数')
#     # 此处 api 对应前端 sockets 的 api
#     socketio.emit('api', {'data': 'test_OK'}, namespace='api')

# if __name__ == '__main__':
#     socketio.run(app, host='127.0.0.1', port='5000',debug=True)  # 注意不再使用app.run
from flask import Flask
# from flask_sqlalchemy import SQLAlchemy
# import pymysql
# from flask import request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, send, emit
import urllib.parse

# pymysql.install_as_MySQLdb()

app = Flask(__name__)

CORS(app, cors_allowed_origins="*")

socketio = SocketIO(app, cors_allowed_origins='*')


@socketio.on('message')
def handle_message(message):
    message = urllib.parse.unquote(message)
    print(message)
    send(message, broadcast=True)


@socketio.on('connect', namespace='/chat')
def test_connect():
    emit('my response', {'data': 'Connected'})


@socketio.on('disconnect', namespace='/chat')
def test_disconnect():
    print('Client disconnected')


if __name__ == '__main__':
    socketio.run(app, debug=True, host="0.0.0.0", port=5000)
